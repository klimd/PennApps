Reality Filter
========

A demo showing how to use HTML5, JavaScript, WebGL and Google Cardboard to create a manipulated view of the world around you via your phone's front camera.

If you make something brilliant from this code, please do let me know! I'm on Twitter at @thatpatrickguy, or you can find me at http://www.patrickcatanzariti.com.

PatCat